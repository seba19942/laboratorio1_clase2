//Numero de iteraciones indefinido

//Forma 1 (mas correcta)
do{
 	//Codigo
}while(confirm("Desea reingresar?"));

//Forma 2 (menos correcta)
confirm = true;

while(confirm){
	//codigo
	confirm = confirm("Desea reingresar?");
}

//Numero de iteraciones determinado (5 iteraciones)
var contador = 0;
while (contador < 5){
	//Codigo
	contador++;
}

for(var contador = 0; contador < 5; contador++){
	//Codigo
}
